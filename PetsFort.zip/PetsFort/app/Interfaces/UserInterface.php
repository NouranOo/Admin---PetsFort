<?php

namespace App\Interfaces;

interface UserInterface
{

    public function SignIn($data);
    public function SignUp($data);
    public function MakePetProfile($data);
    /* public function RecoverEmail($data); */
    public function AskQuestion($data);
    public function PostComment($data);
    public function PostReplay($data);
    public function GetUserPets($data);
    public function GetQuestions($data);
    public function GetQuestionById($data);
    public function GetMyQuestions($data);
    public function ShowUserProfileById($data);
    public function ShowPetProfileById($data);
    public function GetAllUsers($data);
    public function LikeUserProfile($data);
    public function LikePetProfile($data);
    public function LovePetProfile($data);
    public function SearchPet($data);
    public function SendMessage($data);
    public function GetAllMessagesByUserId($data);
    public function GetMyNotfication($data);
    public function ShowMessageById($data);
    public function SendFriendRequest($data);
    public function SendMatcheRequest($data);
    public function GetMyComingFriendRequests($data);
    public function GetMyComingMatchesRequest($data);
    public function AcceptMatchRequest($data);
    public function AcceptFriendRequest($data);
    public function RejectMatchRequest($data);
    public function RejectFriendRequest($data);

    public function GetUserFriends($data);
    public function GetUserMatchesPets($data);

 
    /* public function UploadPetIMages($data); */

}
