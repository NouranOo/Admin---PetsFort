<?php

namespace App\Models;

use Illuminate\Auth\Authenticatable;
use Laravel\Lumen\Auth\Authorizable;
use Illuminate\Database\Eloquent\Model;
 

class PetProfile extends Model  
{
 
    protected $table="PetProfiles";
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'Type', 'Photo','Love','Like','BirthDay','Gender','User_id','Name','Bread'
    ];

     public function User(){
         return $this->belongTo('App\Models\User','User_id');
     }
   
}
