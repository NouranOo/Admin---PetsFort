<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It is a breeze. Simply tell Lumen the URIs it should respond to
| and give it the Closure to call when that URI is requested.
|
 */

$router->get('/', function () use ($router) {
    return 'Hello in PetsFort Apies';
});

/**
 * UserAuth
 */

$router->group(['prefix' => 'Api/User', 'middleware' => ['cors2', 'cors']], function () use ($router) {
    $router->post('/SignUp', 'UserController@SignUp');
    $router->post('/SignIn', 'UserController@SignIn');
});
$router->group(['prefix' => 'Api/User', 'middleware' => ['cors2', 'cors', 'UserAuth']], function () use ($router) {
    $router->post('MakePetProfile', 'UserController@MakePetProfile');
    $router->post('AskQuestion', 'UserController@AskQuestion');
    $router->post('PostComment', 'UserController@PostComment');
    $router->post('PostReplay', 'UserController@PostReplay');
    $router->post('GetUserPets', 'UserController@GetUserPets');
    $router->post('GetQuestions', 'UserController@GetQuestions');
    $router->post('ShowUserProfileById', 'UserController@ShowUserProfileById');
    $router->post('ShowPetProfileById', 'UserController@ShowPetProfileById');
    $router->post('GetAllUsers', 'UserController@GetAllUsers');
    $router->post('LikeUserProfile', 'UserController@LikeUserProfile');
    $router->post('LovePetProfile', 'UserController@LovePetProfile');
    $router->post('LikePetProfile', 'UserController@LikePetProfile');
    $router->post('SearchPet', 'UserController@SearchPet');
    $router->post('SendMessage', 'UserController@SendMessage');
    $router->post('GetMyConversion', 'UserController@GetAllMessagesByUserId');
    $router->post('GetMyNotfication', 'UserController@GetMyNotfication');
    $router->post('ShowMessageById', 'UserController@ShowMessageById');
    $router->post('SendFriendRequest', 'UserController@SendFriendRequest');
    $router->post('SendMatcheRequest', 'UserController@SendMatcheRequest');
    $router->post('GetMyComingFriendRequests', 'UserController@GetMyComingFriendRequests');
    $router->post('GetMyComingMatchesRequest', 'UserController@GetMyComingMatchesRequest');
    $router->post('AcceptMatchRequest', 'UserController@AcceptMatchRequest');
    $router->post('AcceptFriendRequest', 'UserController@AcceptFriendRequest');
    $router->post('RejectFriendRequest', 'UserController@RejectFriendRequest');
    $router->post('RejectMatchRequest', 'UserController@RejectMatchRequest');
    $router->post('GetUserFriends', 'UserController@GetUserFriends');
    $router->post('GetUserMatchesPets', 'UserController@GetUserMatchesPets');
    $router->post('GetQuestionById', 'UserController@GetQuestionById');

});
